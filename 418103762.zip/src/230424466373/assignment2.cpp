/*
Author: Thomas Mlelwa
Registration: 230424466373
*/
#include <fstream>
#include <unordered_map>
using namespace std;
int main(){ifstream in("data/input.txt");ofstream out("data/output.txt");int T; if(!(in>>T)) return 0; out<<"230424466373\n";for(int tc=0;tc<T;++tc){unordered_map<long long,int> seen;int old,x,y,id=1;while(in>>old>>x>>y){if(x==-1&&y==-1)break; long long k=((long long)x<<32)|(unsigned int)y; if(!seen.count(k)){seen[k]=id; out<<id++<<" "<<x<<" "<<y<<"\n";}} out<<"**********\n";} }
